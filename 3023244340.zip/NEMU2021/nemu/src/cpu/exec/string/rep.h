#ifndef __REP_H__
#define __REP_H__

make_helper(rep);
make_helper(repnz);

#endif
