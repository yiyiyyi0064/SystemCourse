#ifndef __XCHG_H__
#define __XCHG_H__

make_helper(xchg_r2rm_b);

make_helper(xchg_a2r_v);
make_helper(xchg_r2rm_v);

#endif
