#ifndef __DMA_H__
#define __DMA_H__

#define BMR_PORT 0xc040

void dma_prepare(void *);

#endif
